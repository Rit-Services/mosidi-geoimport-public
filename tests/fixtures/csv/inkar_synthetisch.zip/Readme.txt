SYNTHETISCHE Testdaten im Aufbau von INKAR 2025 – keine echten Werte.
